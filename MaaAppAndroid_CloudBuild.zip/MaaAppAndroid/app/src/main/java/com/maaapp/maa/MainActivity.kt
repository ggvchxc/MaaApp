package com.maaapp.maa

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : Activity() {
    private var qty = 1
    private var db: FirebaseFirestore? = null
    private lateinit var status: TextView
    private lateinit var total: TextView
    private val pricePerBottle = 2000

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            if (FirebaseApp.initializeApp(this) != null) db = FirebaseFirestore.getInstance()
        } catch (_: Exception) { db = null }
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 28, 28, 28); textDirection = View.TEXT_DIRECTION_RTL }
        val title = TextView(this).apply { text = "ماء 💧"; textSize = 34f; setTextColor(Color.rgb(18,115,150)); gravity = Gravity.CENTER; setPadding(0,20,0,8) }
        val sub = TextView(this).apply { text = "اطلب ماي... يوصلك للبيت"; textSize = 18f; gravity = Gravity.CENTER; setPadding(0,0,0,28) }
        root.addView(title); root.addView(sub)

        val qLabel = TextView(this).apply { text = "عدد قناني 20 لتر"; textSize = 19f; setPadding(0,10,0,8) }
        root.addView(qLabel)
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        listOf(1,2,3,5,10).forEach { n ->
            val b = Button(this).apply { text = n.toString(); setOnClickListener { qty = n; total.text = "المجموع: ${qty*pricePerBottle} د.ع" } }
            row.addView(b, LinearLayout.LayoutParams(0,55,1f).apply { setMargins(3,3,3,3) })
        }
        root.addView(row)

        val name = EditText(this).apply { hint = "اسم الزبون"; textSize = 17f }
        val phone = EditText(this).apply { hint = "رقم الهاتف"; inputType = 2; textSize = 17f }
        val address = EditText(this).apply { hint = "المنطقة والعنوان"; minLines = 2; gravity = Gravity.TOP; textSize = 17f }
        root.addView(name); root.addView(phone); root.addView(address)

        total = TextView(this).apply { text = "المجموع: 2000 د.ع"; textSize = 21f; gravity = Gravity.CENTER; setPadding(0,20,0,12) }
        root.addView(total)
        val order = Button(this).apply { text = "اطلب الآن"; textSize = 19f; setOnClickListener { submit(name.text.toString(), phone.text.toString(), address.text.toString()) } }
        root.addView(order)
        status = TextView(this).apply { textSize = 16f; gravity = Gravity.CENTER; setPadding(0,20,0,0) }
        root.addView(status)
        setContentView(root)
    }

    private fun submit(name: String, phone: String, address: String) {
        if (name.isBlank() || phone.isBlank() || address.isBlank()) { status.text = "⚠️ املأ الاسم ورقم الهاتف والعنوان"; return }
        val data = hashMapOf<String, Any>(
            "customerName" to name, "phone" to phone, "address" to address,
            "quantity" to qty, "price" to qty * pricePerBottle,
            "status" to "جديد", "payment" to "الدفع عند الاستلام",
            "createdAt" to FieldValue.serverTimestamp()
        )
        val firestore = db
        if (firestore == null) {
            status.text = "✅ تم تسجيل الطلب تجريبيًا. اربط Firebase لإرسال الطلبات للسيرفر."
            return
        }
        status.text = "جاري إرسال الطلب..."
        firestore.collection("orders").add(data).addOnSuccessListener { ref ->
            status.text = "✅ تم الطلب بنجاح\nرقم الطلب: ${ref.id}\nالحالة: جديد"
        }.addOnFailureListener { e -> status.text = "❌ تعذر إرسال الطلب: ${e.message}" }
    }
}
